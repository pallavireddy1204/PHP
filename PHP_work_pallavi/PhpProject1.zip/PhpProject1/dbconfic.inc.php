<?php

$dbPassword="phpjava";
$dbUser="phpjava";
$dbServer="localhost";
$dbName="phpjava";
$connection= new mysqli($dbServer,$dbUser,$dbPassword,$dbName);

if($connection-> connect_errno){
    exit("Database connection failed. Reason ".$connection->connect_error);
}
?>